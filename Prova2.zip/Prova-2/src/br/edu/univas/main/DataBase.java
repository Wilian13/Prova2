package br.edu.univas.main;

import java.util.List;
import java.util.Map;

public class DataBase {

	static List<Doador> doadores;
	
	static Map<String, Long> estoqueSanguineo;
	
	
	
	public static void addDoador(Doador doador) {
		
		
		
		

	}
	public static void addDoacao(String tipoSanguineo, Long quantidade) {
		
		
		
		
	}
	public static void getSituacaoEstoque(String tipoSanguineo) {
		
		
		
		

	}
}
