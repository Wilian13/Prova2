package br.edu.univas.main;

public class TipoSanguineoNotFoundException extends RuntimeException {

}
