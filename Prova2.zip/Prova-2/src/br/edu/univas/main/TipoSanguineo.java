package br.edu.univas.main;

public enum TipoSanguineo {

	APOSITIVO;
	private String ANEGATIVO;
	private String BPOSITIVO;
	private String BNEGATIVO;
	private String ABPOSITIVO;
	private String ABNEGATIVO;
	private String OPOSITIVO;
	private String ONEGATIVO;
	
	
	
	public void TipoSanguineo (String tipo) {
		
		
		
		
		
		
	}
	
	public static void getTipo () {
		
		
		
		
	}
	public static void fromTipo (String tipo) {
		
		
		
	}

}