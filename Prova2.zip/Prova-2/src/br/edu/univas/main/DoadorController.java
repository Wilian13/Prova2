package br.edu.univas.main;

public class DoadorController {

	
	public void CadastrarDoador(Long cpf, String Tiposanguineo) {
		
		
		
		
	}
	public void CadastrarDoacao(String Tiposanguineo, Long quantidade) {
		
		
		
	}
	
	
}
