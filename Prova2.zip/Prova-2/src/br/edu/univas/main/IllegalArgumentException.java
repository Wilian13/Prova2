package br.edu.univas.main;

public class IllegalArgumentException extends RuntimeException {

}
