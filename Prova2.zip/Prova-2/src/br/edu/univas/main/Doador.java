package br.edu.univas.main;

public class Doador {

	
	private long cpf;
	private TipoSanguineo tiposanguineo;
	
	
	
	
	public long getCpf() {
		return cpf;
	}
	public void setCpf(long cpf) {
		this.cpf = cpf;
	}
	public TipoSanguineo getTiposanguineo() {
		return tiposanguineo;
	}
	public void setTiposanguineo(TipoSanguineo tiposanguineo) {
		this.tiposanguineo = tiposanguineo;
	}
}
